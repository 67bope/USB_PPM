R9M:
both dipswitches to "on" (Automode)
flexfirmware

R9MM:
flexfirmware